# Git・リリース・公開支援 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | WindowsApp |
| No. | 7 |
| 分野 | リリース・公開 |
| アイデア | Git・リリース・公開支援 |
| リポジトリ名 | git-release-publish-assistant |
| 概要 | Git健康診断、ブランチ掃除、Unity package、Installer、Pagesリンクを確認する。 入力、確認、履歴保存、次アクションを同じ作業単位で扱えるようにする。 |
| 課題 | リリース前作業が複数ツールに分かれ、証跡が残りにくい。 |
| 類似サービス・アプリ | Microsoft PowerToys, Notion, Obsidian, Ditto, ShareX, FreeFileSync, GitHub Desktop |
| 差別化ポイント | ローカル検証から公開前チェックまでを1つのデスクトップ導線にする。 |

## 目的

このZIPには、`WindowsApp` 領域のアイデア `Git・リリース・公開支援` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
