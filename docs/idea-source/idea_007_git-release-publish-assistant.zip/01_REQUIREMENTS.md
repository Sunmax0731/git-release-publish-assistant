# 01 要件定義: Git・リリース・公開支援

## 背景

Git健康診断、ブランチ掃除、Unity package、Installer、Pagesリンクを確認する。 入力、確認、履歴保存、次アクションを同じ作業単位で扱えるようにする。

## 課題

リリース前作業が複数ツールに分かれ、証跡が残りにくい。

## 対象ユーザー

- `リリース・公開` 領域で継続的に作業するユーザー。
- 既存の代替手段が広すぎる、重すぎる、または分断されていると感じているユーザー。
- 入力、確認、処理、出力、履歴を一つの流れで扱いたいユーザー。

## ユーザー価値

- ツールや画面を行き来する負担を減らす。
- 判断、設定、結果、エラーを後から追える形で残す。
- 製品上で次の差別化ポイントが分かるようにする: ローカル検証から公開前チェックまでを1つのデスクトップ導線にする。

## MVP機能要件

- FR-1: ユーザーは対象データまたは作業項目を入力、選択、取り込みできる。
- FR-2: ユーザーは取り込んだ内容を一覧、プレビュー、状態ビューで確認できる。
- FR-3: 中核となる `リリース・公開` の処理を実行できる。
- FR-4: 結果、判断、エラー、履歴を保存または書き出しできる。
- FR-5: 失敗時は原因、再試行、スキップ、復旧操作を表示する。

## Non-functional Requirements

- Keep small personal datasets responsive.
- Require confirmation or preview before destructive actions.
- Do not send local files, credentials, or assets externally without explicit intent.
- Keep enough logs for troubleshooting and repeatability.

## Out of Scope for MVP

- Replacing every feature of similar products.
- Complex team permission management.
- Automation that depends on unverified third-party terms or unstable pages.

## Acceptance Criteria

- The main flow works from input to output/save.
- Normal, failure, and cancel paths can be tested.
- The differentiation is visible in UI or workflow behavior.
